package com.google.FindLocationActivity;

import com.google.android.maps.MyLocationOverlay;

import android.app.Activity;
import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class FindLocationActivity extends Activity implements LocationListener {
    
	LocationManager locationmanager;
	Location location;
	String LastLocation;
	private TextView myLocation;
	
	Boolean isgps;
	Boolean isnetwork;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        myLocation = (TextView)findViewById(R.id.MyLoationId);
        
        String sevice =Context.LOCATION_SERVICE;
        locationmanager = (LocationManager)getSystemService(sevice);
        isgps= locationmanager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        isnetwork=locationmanager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        if(!isgps && !isnetwork)
        {
        	Toast.makeText(FindLocationActivity.this, "Fool", Toast.LENGTH_LONG).show();
        }
        else
        {
        	if(isgps)
        	{
        		locationmanager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0,0,FindLocationActivity.this);
        		if(locationmanager!=null)
        		{
        			location=locationmanager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        			if(location!=null)
        			{
        				Toast.makeText(FindLocationActivity.this,"Your Location is"+ location.getLatitude()+ " " + location.getLongitude() ,Toast.LENGTH_LONG).show();
        			}
        			else
        			{
        				Toast.makeText(FindLocationActivity.this, "Sorry", Toast.LENGTH_LONG).show();
        			}
        		}
        		else
        		{
    				Toast.makeText(FindLocationActivity.this, "Sorry no gp lm", Toast.LENGTH_LONG).show();
        		}
        	}
        	
        	if(isnetwork)
        	{
        		locationmanager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0,0,FindLocationActivity.this);
        		if(locationmanager!=null)
        		{
        			location=locationmanager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
        			if(location!=null)
        			{
        				Toast.makeText(FindLocationActivity.this,"Your Location is"+ location.getLatitude()+ " " + location.getLongitude() ,Toast.LENGTH_LONG).show();
        			}
        			else
        			{
        				Toast.makeText(FindLocationActivity.this, "Sorry", Toast.LENGTH_LONG).show();
        			}
        		}
        		else
        		{
    				Toast.makeText(FindLocationActivity.this, "Sorry no net lm", Toast.LENGTH_LONG).show();
        		}
        	}
        }
        
        
        
        
        //String provider = LocationManager.NETWORK_PROVIDER;
        //Location location = locationmanager.getLastKnownLocation(provider);
        
        //updateWithNewLocation(location);
    }

	public void onLocationChanged(Location location) {
		// TODO Auto-generated method stub
		myLocation.setText("Your Location is"+ location.getLatitude()+ " " + location.getLongitude());
		Toast.makeText(FindLocationActivity.this,"Your Location is"+ location.getLatitude()+ " " + location.getLongitude() ,Toast.LENGTH_LONG).show();
	}

	public void onProviderDisabled(String provider) {
		// TODO Auto-generated method stub
		Toast.makeText(FindLocationActivity.this,"test2" + provider ,Toast.LENGTH_LONG).show();

	}

	public void onProviderEnabled(String provider) {
		// TODO Auto-generated method stub
		Toast.makeText(FindLocationActivity.this,"test" + provider ,Toast.LENGTH_LONG).show();

	}

	public void onStatusChanged(String provider, int status, Bundle extras) {
		// TODO Auto-generated method stub
		
	}

	private void updateWithNewLocation(Location location) {
		// TODO Auto-generated method stub
		
		String LastLocation;
		TextView myLocation = (TextView)findViewById(R.id.MyLoationId);
		
		if(location != null)
		{
			double lng = location.getLongitude();
			double lat = location.getLatitude();
			LastLocation = "\nLatitude :" + lat + "\nLongitude" + lng;
		}
		else
		{
			LastLocation = "No Location Found !";
		}	
		myLocation.setText("Your Location Position is : " + LastLocation);
	}

}