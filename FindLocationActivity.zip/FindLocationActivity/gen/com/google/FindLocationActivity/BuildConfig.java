/** Automatically generated file. DO NOT MODIFY */
package com.google.FindLocationActivity;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}